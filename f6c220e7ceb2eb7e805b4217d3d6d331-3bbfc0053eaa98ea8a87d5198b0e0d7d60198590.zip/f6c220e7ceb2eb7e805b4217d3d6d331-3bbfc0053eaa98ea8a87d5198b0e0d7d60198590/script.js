// Riproduzione canzone
const playButton = document.getElementById('play-music');
playButton.addEventListener('click', () => {
    // Apre una nuova finestra con il video di YouTube
    window.open('https://www.youtube.com/watch?v=8EdqKkc7Uto', '_blank');
});

// Variabili per fotocamera
const startCameraButton = document.getElementById('start-camera');
const takePhotoButton = document.getElementById('take-photo');
const cameraContainer = document.getElementById('camera-container');
const video = document.getElementById('video');
const photoContainer = document.getElementById('photo-container');

let stream;

// Attiva la fotocamera
startCameraButton.addEventListener('click', () => {
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(s => {
            stream = s;
            video.srcObject = stream;
            cameraContainer.style.display = 'block';
            startCameraButton.style.display = 'none';
            takePhotoButton.style.display = 'inline-block';
        })
        .catch(err => {
            console.log("Errore nell'accesso alla fotocamera: ", err);
        });
});

// Funzione per scattare foto
takePhotoButton.addEventListener('click', () => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Salva la foto
    const imgData = canvas.toDataURL();
    const img = document.createElement('img');
    img.src = imgData;
    photoContainer.appendChild(img);

    // Termina lo stream
    stream.getTracks().forEach(track => track.stop());

    // Nasconde la fotocamera e il tasto "Scatta Foto"
    cameraContainer.style.display = 'none';
    takePhotoButton.style.display = 'none';
    startCameraButton.style.display = 'inline-block';
});